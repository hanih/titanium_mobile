var WindowManager = require('helper/WindowManager');
var Utils = require('helper/Utils');
var Cloud = require('ti.cloud');
exports['Update Photo'] = function(evt) {
	var win = WindowManager.createWindow({
		backgroundColor: 'white'
	});
	var content = Ti.UI.createScrollView({
		top: 0,
		contentHeight: 'auto',
		layout: 'vertical'
	});
	win.add(content);

	var replacement;

	if (Ti.Media.openPhotoGallery) {
		var selectPhoto = Ti.UI.createButton({
			title: 'Select Photo from Gallery',
			top: 10 + Utils.u,
			left: 10 + Utils.u,
			right: 10 + Utils.u,
			bottom: 10 + Utils.u,
			height: 40 + Utils.u
		});
		selectPhoto.addEventListener('click', function(evt) {
			Ti.Media.openPhotoGallery({
				success: function(e) {
					replacement = e.media;
				}
			});
		});
		content.add(selectPhoto);
	}
	if (Ti.Media.showCamera) {
		var takePhoto = Ti.UI.createButton({
			title: 'Take Photo with Camera',
			top: 10 + Utils.u,
			left: 10 + Utils.u,
			right: 10 + Utils.u,
			bottom: 10 + Utils.u,
			height: 40 + Utils.u
		});
		takePhoto.addEventListener('click', function(evt) {
			Ti.Media.showCamera({
				success: function(e) {
					replacement = e.media;
				}
			});
		});
		content.add(takePhoto);
	}

	var collectionID;
	var chooseCollection = Ti.UI.createButton({
		title: 'Choose Collection',
		top: 10 + Utils.u,
		left: 10 + Utils.u,
		right: 10 + Utils.u,
		bottom: 10 + Utils.u,
		height: 40 + Utils.u
	});
	chooseCollection.addEventListener('click', function(evt) {
		var table = Ti.UI.createTableView({
			backgroundColor: '#fff',
			color: 'black',
			data: [{
				title: 'Loading, please wait...'
			}]
		});
		table.addEventListener('click', function(evt) {
			collectionID = evt.row.id;
			win.remove(table);
		});
		win.add(table);

		function findCollections(userID) {
			Cloud.PhotoCollections.search({
				user_id: userID
			}, function(e) {
				if (e.success) {
					if (e.collections.length == 0) {
						win.remove(table);
						alert('No photo collections exist! Create one first.');
					} else {
						var data = [];
						data.push(Ti.UI.createTableViewRow({
							color: 'black',
							title: 'No Collection',
							id: '',
							hasCheck: !collectionID
						}));
						(function enumCollections(collections, prefix) {
							for (var i = 0, l = collections.length; i < l; i++) {
								data.push(Ti.UI.createTableViewRow({
									title: prefix + collections[i].name,
									id: collections[i].id,
									color: 'black',
									hasCheck: collectionID == collections[i].id
								}));
								if (collections[i].subcollections) {
									enumCollections(collections[i].subcollections, collections[i].name + ":");
								}
							}
						})(e.collections, '');
						table.setData(data);
					}
				} else {
					win.remove(table);
					Utils.error(e);
				}
			});
		}

		Cloud.Users.showMe(function(e) {
			if (e.success) {
				findCollections(e.users[0].id);
			} else {
				table.setData([{
					title: (e.error && e.message) || e
				}]);
				Utils.error(e);
			}
		});
	});
	content.add(chooseCollection);

	var tags = Ti.UI.createTextField({
		hintText: 'Tags (csv)',
		top: 10 + Utils.u,
		left: 10 + Utils.u,
		right: 10 + Utils.u,
		height: 40 + Utils.u,
		borderStyle: Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
		autocapitalization: Ti.UI.TEXT_AUTOCAPITALIZATION_NONE,
		autocorrect: false,
		color: "black",
		hintTextColor: "gray"
	});
	content.add(tags);

	var button = Ti.UI.createButton({
		title: 'Update',
		top: 10 + Utils.u,
		left: 10 + Utils.u,
		right: 10 + Utils.u,
		bottom: 10 + Utils.u,
		height: 40 + Utils.u
	});
	content.add(button);

	if (Ti.UI.createProgressBar) {
		var uploadProgress = Ti.UI.createProgressBar({
			top: 10 + Utils.u,
			right: 10 + Utils.u,
			left: 10 + Utils.u,
			max: 1,
			min: 0,
			value: 0,
			height: 25 + Utils.u
		});
		content.add(uploadProgress);
		uploadProgress.show();
	}

	var fields = [tags];

	function submitForm() {
		for (var i = 0; i < fields.length; i++) {
			if (!fields[i].value.length) {
				fields[i].focus();
				return;
			}
			fields[i].blur();
		}
		button.hide();

		if (replacement && Ti.UI.createProgressBar) {
			Cloud.onsendstream = function(evt) {
				uploadProgress.value = evt.progress * 0.5;
			};
			Cloud.ondatastream = function(evt) {
				uploadProgress.value = (evt.progress * 0.5) + 0.5;
			};
		}
		Cloud.Photos.update({
			photo_id: evt.id,
			photo: replacement,
			tags: tags.value,
			collection_id: collectionID
		}, function(e) {
			if (replacement) {
				Cloud.onsendstream = Cloud.ondatastream = null;
			}
			if (e.success) {
				replacement = null;
				alert('Updated!');
			} else {
				Utils.error(e);
			}
			button.show();
		});
	}

	button.addEventListener('click', submitForm);
	for (var i = 0; i < fields.length; i++) {
		fields[i].addEventListener('return', submitForm);
	}

	var status = Ti.UI.createLabel({
		text: 'Loading, please wait...',
		textAlign: 'center',
		top: 0,
		right: 0,
		bottom: 0,
		left: 0,
		backgroundColor: '#fff',
		zIndex: 2,
		color: 'black'
	});
	win.add(status);

	win.addEventListener('open', function() {
		Cloud.Photos.show({
			photo_id: evt.id
		}, function(e) {
			status.hide();
			if (e.success) {
				var photo = e.photos[0];
				if (photo.collections && photo.collections.length > 0) {
					collectionID = photo.collections[0].id;
				}
				tags.value = photo.tags && photo.tags.join(',');
				tags.focus();
			} else {
				Utils.error(e);
			}
		});
	});
	return win;
};
